export const baseUrl = 'http://localhost:3030';

export const movies = `${baseUrl}/data/movies`; 