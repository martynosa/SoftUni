function attachEvents() {
    console.log("TODO...");
}

attachEvents();