
// една функция с ред който връща n на брой пъти числото/.repeat() и после да го принтираме n пъти
function matrix(n) {


}
let result = matrix();
console.log(result);
