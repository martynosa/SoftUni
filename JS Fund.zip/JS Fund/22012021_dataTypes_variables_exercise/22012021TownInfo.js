function solve(town, population, area) {

    console.log (`Town ${town} has population of ${population} and area ${area} square km.`)

}
solve()