
function solve(p) {
    let d = p * 1.31

    console.log(d.toFixed(3))

}
solve(80)