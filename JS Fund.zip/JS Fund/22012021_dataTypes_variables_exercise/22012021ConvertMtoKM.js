function solve(m) {

    let km = m/ 1000
    console.log(km.toFixed(2)) // always returns string

}
solve(1852)