function solve(a, b,c) {

    console.log(c, b, a)

}
solve('a','b','c')