function solve(a, b, c) {

    console.log(a + b + c)

}
solve('a',
    'b',
    'c')