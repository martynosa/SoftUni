function solve(text){
    for (const symbol of text) {    //как се итерира
        console.log(symbol);        //през текст
    }

    console.log(text[0])

}
solve(`Marto`);