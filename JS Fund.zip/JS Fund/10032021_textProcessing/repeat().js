function solve(input) {
                                    
    console.log(input.repeat(3)); //повтаря текста 3 пъти
}                                               
solve(`Java`)