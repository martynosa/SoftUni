function solve(text) {
console.log(`->` + text.trim() + `<-`); //премахва space от 
}                                       //началото и края само 
solve(` Java script `)                  //таблуация(четири space) \t
                                        //нов ред \n
                                        //trimStart() и trimEnd()