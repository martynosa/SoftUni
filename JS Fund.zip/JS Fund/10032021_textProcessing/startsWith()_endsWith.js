function solve(text) {
    console.log(text.startsWith(`Java`)); //връща дали започва с думата(true/false)
}                                         //endsWith() - дали завършва s думата
solve(`JavaScript`)