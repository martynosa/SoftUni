

function objectsDemo() {

    let cat = {
        name: `Lory`,
        age: 5,
        color: `black`

    }


}
objectsDemo();