function map(){

    let string = `5`;
    let number = +string;
    console.log(typeof number);

}
map();