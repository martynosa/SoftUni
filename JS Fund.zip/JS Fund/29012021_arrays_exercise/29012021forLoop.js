
function demo() {

    let arr = ['Peter', 'Ana', 'Ivan', 'Tim'];

    for ( let i = 0; i< arr.length; i++) {

        console.log(arr[i]);
    }

}
demo();